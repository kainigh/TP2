using TMPro;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;



public class UIBehaviour : MonoBehaviour
{
    TMP_Text coinText;
    int nbCoins = 0;
    public float currentTime = 100;
    TMP_Text timerText;

    void Start()
    {
        StartCoroutine(TimerTick());
        coinText = GameObject.Find("lblCoins").GetComponent<TMPro.TMP_Text>();
        timerText = GameObject.Find("lblTime").GetComponent<TMPro.TMP_Text>();
    }
    void Update()
    {




    }
    public void AddHit()
    {
        nbCoins++;
        coinText.text = "Coins: " + nbCoins;
    }

    IEnumerator TimerTick()
    {
        

        while (currentTime > 0)
        {
            // attendre une seconde
            yield return new WaitForSeconds(1);
            currentTime--;
            timerText.text = "Time :" + currentTime.ToString();
        }
        // game over
        SceneManager.LoadScene("sceneTerrain"); // le nom de votre scene
    }
}