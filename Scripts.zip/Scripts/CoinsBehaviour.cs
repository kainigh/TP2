using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinsBehaviour : MonoBehaviour
{
   
    AudioSource collisionSound;
    public GameObject fx;
    public GameObject worldObject;


    // Start is called before the first frame update
    void Start()
    {
        worldObject = GameObject.Find("World");
        collisionSound = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
        worldObject.SendMessage("AddHit");

        Instantiate(fx, transform.position, Quaternion.identity);
        // OnCollisionEnter
        if (other.tag == "Player")
        {
            Destroy(gameObject);
        }

        if (collisionSound)
        {
            collisionSound.Play();

        }
    }
}
