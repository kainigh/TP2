using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StaticVariables : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public static class GameVariables
    {
        public static int allowedTime = 90;
        public static int currentTime = GameVariables.allowedTime;
    }


}
